"""Short-lived, token protected loopback bridge. No customer credentials embedded."""
import json
import secrets
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlencode, urlparse, parse_qs

ORDER_URL = 'https://www.diyipcb.com/product/pcb-pcba-order-online/'
ORIGINS = {'https://www.diyipcb.com', 'https://diyipcb.com'}
ACTIVE = []

def start_handoff(result, open_browser=True, lifetime=600):
    token = secrets.token_urlsafe(32)
    files = {role: Path(result[role]) for role in ['gerber', 'bom', 'centroid']}
    if any(p.stat().st_size > 20 * 1024 * 1024 for p in files.values()) or sum(p.stat().st_size for p in files.values()) > 40 * 1024 * 1024:
        raise ValueError('DIYIPCB allows 20 MB per file and 40 MB in total.')
    payload = {'files': {role: {'name': p.name, 'size': p.stat().st_size} for role, p in files.items()},
               'manifest': result['manifest']}
    expiry = time.monotonic() + lifetime

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass  # Token must not be logged.

        def allowed(self):
            parsed = urlparse(self.path)
            return (self.headers.get('Origin') in ORIGINS and
                    self.headers.get('Host') == '127.0.0.1:' + str(self.server.server_port) and
                    secrets.compare_digest(parse_qs(parsed.query).get('token', [''])[0], token) and
                    time.monotonic() < expiry)

        def cors(self):
            self.send_header('Access-Control-Allow-Origin', self.headers.get('Origin', ''))
            self.send_header('Vary', 'Origin')
            self.send_header('Access-Control-Allow-Private-Network', 'true')
            self.send_header('Cache-Control', 'no-store')

        def do_OPTIONS(self):
            if not self.allowed():
                self.send_error(403)
                return
            self.send_response(204)
            self.cors()
            self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
            self.end_headers()

        def do_GET(self):
            if not self.allowed():
                self.send_error(403)
                return
            route = urlparse(self.path).path
            if route == '/manifest':
                body, mime = json.dumps(payload).encode(), 'application/json'
            elif route[1:] in files:
                body = files[route[1:]].read_bytes()
                mime = 'application/zip' if route == '/gerber' else 'text/csv; charset=utf-8'
            else:
                self.send_error(404)
                return
            self.send_response(200)
            self.cors()
            self.send_header('Content-Type', mime)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    ACTIVE.append(server)
    threading.Thread(target=server.serve_forever, daemon=True).start()

    def close():
        server.shutdown()
        server.server_close()
        if server in ACTIVE:
            ACTIVE.remove(server)
    timer = threading.Timer(lifetime, close)
    timer.daemon = True
    timer.start()
    url = ORDER_URL + '#' + urlencode({'diyi_kicad': '1', 'port': server.server_port, 'token': token})
    if open_browser:
        webbrowser.open(url)
    return server, url, close
