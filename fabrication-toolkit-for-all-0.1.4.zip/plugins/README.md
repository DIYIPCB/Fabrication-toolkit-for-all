# Fabrication Tookit for All / DIYIPCB Plug-in for KiCad

两个独立的 KiCad PCB Editor 插件，版本 0.1.4（testing）。名称按用户指定的 Tookit 保留。
代码为独立实现；参考 KiCad 官方 PCM 规范和 PCBWay 插件功能，未复制 PCBWay 源码。

## 安装

KiCad 主窗口 → 插件与内容管理器 → 从文件安装，选择 dist 中对应 ZIP，重启 PCB 编辑器。
可同时安装两个插件。菜单“工具 → 外部插件”或工具栏打开。

生成前显示 Options 对话框：可填写压缩包名称、选择输出目录，勾选填充覆铜、排除生产 BOM 中的 DNP、生成后打开浏览器导入 DIYIPCB、包含 PCB 快照。
填充覆铜、排除 DNP 和打开浏览器默认勾选。两种插件均可通过该选项打开下单页。
排除 DNP 时额外生成 BOM-All.csv 保留完整设计清单。覆铜只在导出副本上执行；原设计不保存或修改。
使用 pcbnew SWIG API，最低声明 KiCad 8；已实测本机 KiCad 10.0.5 导出引擎，8/9 尚未实机验证。
已测试安装 ZIP 的 Python 导入；PCM 安装和编辑器内工具栏点击仍需人工验收，不能在独立 Python 进程执行原生动作注册。
不支持未来移除 SWIG 的 KiCad 版本，届时需迁移到 IPC API。

先在原理图中维护 Manufacturer、Part Number/MPN、Substitution、Datasheet、DNP 等字段，
执行“从原理图更新 PCB”并保存。插件对未保存的 PCB 更改报错，避免交付旧版本。
默认导出目录为 PCB 同目录下的 `Fabrication files`。选择其他目录时也会在其下创建 `Fabrication files`。
文件直接写入此目录，不创建带日期和随机字符的批次子目录。同名输出文件会更新。
生产包先在临时目录完整生成，仅打包本次结果，再复制到输出目录；不修改 PCB、阻焊设置或原理图。

## 输出

| 层 | 文件 |
| --- | --- |
| 顶/底铜 | 板名.GTL / .GBL |
| 内铜，按实际铜层顺序 | 板名.G1 / .G2 / … |
| 顶/底丝印 | 板名.GTO / .GBO |
| 顶/底阻焊 | 板名.GTS / 板名.GBS |
| 顶锡膏 | 板名-F_Paste.GPS |
| 底锡膏 | 板名-B_Paste.GBS |
| 外形 | 板名.GML |
| 钻孔 | 板名-PTH.TXT / 板名-NPTH.TXT（如存在） |

用户要求的底锡膏 .GBS 与底阻焊同尾缀，以 B_Paste 文件名和 Gerber X2 FileFunction 区分。
其他厂商仅按扩展名识别时，应将底锡膏改为 .GBP、顶锡膏改为 .GTP。
盲/埋孔钻孔保留 KiCad 的层对文件名，不合并为通孔。

- BOM.csv：Reference、Quantity、Value、Footprint、Manufacturer、Part Number、Substitution、Datasheet、DNP、LCSC Part #，以及所有额外字段。
  LCSC Part # 自动读取 LCSC、LCSC_PN、LCSC Part Number 等字段，用于 JLCPCB 兼容；没有填写时保留空白。
- BOM-Assembly.csv：去掉 DNP，单板数量。
- CPL.csv：毫米、辅助原点、X 向右、Y 向上、原生 KiCad 逆时针角度，底层不镜像。包含需装配且未排除的 SMD/THT；DNP 不输出。
- procurement-issues.csv：需装器件缺失制造商、完整型号、封装的逐位号报告。
- manifest.json：层映射、来源 SHA256、坐标约定、字段检查、警告。
- Gerber.zip：所有 Gerber 和钻孔。
- Production.zip：整个生产交付包，包括 BOM、CPL、检查报告。

分组同时比较所有字段，避免把不同 MPN、不同制造商、不同替代规则或 DNP 状态合并。
自动排除设置了 Exclude from BOM 的对象；同时排除 BOM/位置的测试点和机械图形不触发重复位号错误。
PCB 字段优先；缺失字段尝试通过 kicad-cli 原理图 XML 网表读取，自动覆盖分层子页。
仅当位号、Value、封装匹配时补充原理图数据；冲突写入警告。不自动选替代型号。

字段完整仅代表输入资料齐全，未验证现货、生命周期、原理图/布局、电气匹配或厂商贴片旋转约定。
仅有阻容值和封装的设计会输出缺失 MPN，不会猜测型号。CSV 保留原始单元格文本；请通过表格软件“导入文本”查看外来 BOM。

## DIYIPCB 下单接入

当前 DIYIPCB 网站已安装并启用接收端；迁移网站时可在 WordPress 安装并启用 dist/diyipcb-kicad-bridge-0.1.1.zip。
接收端仅在现有 PCB 商品 ID 25 的页面加载：
https://www.diyipcb.com/product/pcb-pcba-order-online/

点击 DIYIPCB 插件 → 选择输出目录 → 自动打开该下单页，导入 Gerber、BOM、CPL。
生成前选项框的“Open browser and import files to DIYIPCB after generation”默认勾选，也适用于 Fabrication Tookit for All。
同时传递 KiCad 中的板尺寸和铜层数，避免 Gerber 预览器无法识别时停留在默认参数。
用户继续确认板参数，需要贴片时勾选 assembly，然后按网站现有流程登录和下单。
不自动提交询价、加入购物车或付款。未嵌入 API 密钥或客户密码。

浏览器可能要求允许访问本地设备，允许后才能从本机 KiCad 取文件。
接收端只访问 127.0.0.1 随机端口，随机 token 通过 URL fragment 传递，读取后立即清除。
桥接服务器只允许 diyipcb.com/www.diyipcb.com 来源、正确 Host 和 token，有效期 10 分钟。
只允许读取此次导出的三个文件；没有目录遍历接口。保持 KiCad 打开直到文件导入完成。
文件先填入页面上传栏，后续使用原有登录、用户授权、文件限额、私有存储机制提交。
失败时可以手动上传输出目录里的 Gerber.zip、BOM.csv、CPL.csv。

底锡膏 GBS 不应当作为底阻焊参与网站预览：当前网站已同步过滤掉 -B_Paste.GBS。
迁移到其他环境时，在 pcbBuildCleanZip 的 keepRe 检查之前增加：
`if (/-[FB]_Paste\.(GPS|GBS)$/i.test(nm)) return;`，只过滤预览，不改上传原文件。
如果网站启用严格 CSP，应允许 connect-src http://127.0.0.1:*，否则使用手动上传。
安装 ZIP 是本地 PCM 安装；没有向 KiCad 官方插件库提交上架。

## 开发与验证

python build.py 生成安装包。
使用 KiCad 附带 Python 运行 core.py PCB路径 输出目录，可直接导出并验证。
普通 Python 可运行 core.py --normalize-bom 输入.csv 输出.csv，兼容用户提供的两种 BOM。
python -m unittest discover -s tests 验证字段分组、DNP、数量以及本地桥安全边界。

官方规范：https://dev-docs.kicad.org/en/addons/index.html
参考功能：https://github.com/pcbway/PCBWay-Plug-in-for-Kicad
