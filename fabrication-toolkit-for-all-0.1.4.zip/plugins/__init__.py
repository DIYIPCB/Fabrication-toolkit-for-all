from .action import FabricationAction
FabricationAction().register()
