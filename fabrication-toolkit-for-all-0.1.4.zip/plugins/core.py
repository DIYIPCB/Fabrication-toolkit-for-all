"""Fabrication Toolkit for All: dependency-free BOM and KiCad manufacturing export."""
import csv
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

COLUMNS = ['Reference', 'Quantity', 'Value', 'Footprint', 'Manufacturer',
           'Part Number', 'Substitution', 'Datasheet', 'DNP', 'LCSC Part #']
ALIASES = {
    'Reference': ['Reference', 'Designator', 'Designators', 'References', 'Ref'],
    'Quantity': ['Quantity', 'Qty'],
    'Manufacturer': ['Manufacturer', 'Mfr', 'MFG', 'Manufacturer Name'],
    'Part Number': ['Part Number', 'MPN', 'Manufacturer Part Number', 'Mfr Part Number',
                    'Mfr. No.', 'Mfg Part', 'Manufacturer_Part_Number'],
    'Substitution': ['Substitution', 'Substitutions', 'Substitute', 'Alternates'],
    'Datasheet': ['Datasheet', 'Datasheet URL'],
    'LCSC Part #': ['LCSC Part #', 'LCSC', 'LCSC Part Number', 'LCSC Part',
                    'LCSC Number', 'LCSC PN', 'LCSC_PN', 'JLCPCB Part #', 'JLCPCB Part Number'],
    'DNP': ['DNP', 'DNI', 'Do Not Populate', 'Do Not Fit', 'Custom_DNP'],
}

def key(value):
    return re.sub(r'[^a-z0-9]', '', str(value).lower())

def natural(value):
    return [int(v) if v.isdigit() else v.lower() for v in re.split(r'(\d+)', value)]

def yes(value):
    return str(value).strip().lower() in {'1', 'yes', 'true', 'dnp', 'dni', 'dnf', 'not fitted'}

def canonical(fields):
    normalized = {key(k): str(v or '').strip() for k, v in fields.items()}
    result = {}
    for col in COLUMNS:
        values = [normalized.get(key(a), '') for a in ALIASES.get(col, [col])]
        result[col] = next((v for v in values if v), '')
    result['DNP'] = 'Yes' if any(yes(normalized.get(key(a), '')) for a in ALIASES['DNP']) else 'No'
    return result

def csv_write(path, columns, rows):
    # UTF-8 BOM permits Excel to display international manufacturer/part names.
    with Path(path).open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)

def group_rows(rows):
    groups = {}
    for row in rows:
        identity = tuple((k, str(v)) for k, v in sorted(row.items())
                         if k not in {'Reference', 'Quantity'})
        groups.setdefault(identity, []).append(row)
    result = []
    for items in groups.values():
        row = dict(items[0])
        row['Reference'] = ', '.join(sorted((i['Reference'] for i in items), key=natural))
        row['Quantity'] = len(items)
        result.append(row)
    return sorted(result, key=lambda r: natural(r['Reference']))

def normalize_csv(source, output):
    """Normalize reference BOMs without inventing MPNs or discarding custom fields."""
    rows, seen = [], set()
    with Path(source).open(encoding='utf-8-sig', newline='') as f:
        for raw in csv.DictReader(f):
            row = canonical(raw)
            refs = [r for r in re.split(r'[,;\s]+', row['Reference']) if r]
            if not refs:
                raise ValueError('BOM row lacks references')
            if row['Quantity'] and int(row['Quantity']) != len(refs):
                raise ValueError('Quantity/reference mismatch: ' + row['Reference'])
            extra = {k: v for k, v in raw.items() if key(k) not in
                     {key(a) for c in COLUMNS for a in ALIASES.get(c, [c])}}
            for ref in refs:
                if ref in seen:
                    raise ValueError('Duplicate reference: ' + ref)
                seen.add(ref)
                rows.append(dict(row, **extra, Reference=ref, Quantity=1))
    rows = group_rows(rows)
    columns = COLUMNS + sorted({k for r in rows for k in r if k not in COLUMNS})
    csv_write(output, columns, rows)
    return rows

def schematic_fields(board_path, warnings):
    schematic = board_path.with_suffix('.kicad_sch')
    if not schematic.exists():
        warnings.append('No companion schematic: BOM uses PCB footprint fields only.')
        return {}
    cli = Path(sys.executable).with_name('kicad-cli.exe' if sys.platform == 'win32' else 'kicad-cli')
    cli = str(cli) if cli.exists() else shutil.which('kicad-cli')
    if not cli:
        warnings.append('kicad-cli unavailable: schematic fields could not be read.')
        return {}
    try:
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'netlist.xml'
            subprocess.run([cli, 'sch', 'export', 'netlist', '--format', 'kicadxml',
                            '--output', str(target), str(schematic)], check=True,
                           capture_output=True, timeout=120,
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            result = {}
            for comp in ET.parse(target).findall('.//components/comp'):
                fields = {f.attrib['name']: f.text or '' for f in comp.findall('./fields/field')}
                for prop in comp.findall('./property'):
                    fields[prop.attrib['name']] = prop.attrib.get('value', '')
                fields.update(Value=comp.findtext('value', ''), Footprint=comp.findtext('footprint', ''),
                              Datasheet=comp.findtext('datasheet', ''))
                result[comp.attrib['ref']] = fields
            return result
    except (OSError, subprocess.SubprocessError, ET.ParseError) as exc:
        warnings.append('Schematic field import failed: ' + str(exc))
        return {}

def board_geometry(board):
    import pcbnew
    outline = pcbnew.SHAPE_POLY_SET()
    try:
        valid = board.GetBoardPolygonOutlines(outline, False)
    except TypeError:
        valid = board.GetBoardPolygonOutlines(outline)
    if not valid or not outline.OutlineCount():
        return None
    # Polygon outlines use the Edge.Cuts centreline, not its drawn stroke width.
    bounds = outline.BBox()
    return {'length_mm': pcbnew.ToMM(bounds.GetWidth()),
            'width_mm': pcbnew.ToMM(bounds.GetHeight()),
            'copper_layers': board.GetCopperLayerCount()}

def export_board(board, destination, settings=None):
    import pcbnew
    settings = dict(settings or {})
    source = Path(board.GetFileName())
    if not source.is_file():
        raise ValueError('Save the PCB before export.')
    archive_name = str(settings.get('archive_name', '')).strip() or source.stem
    if archive_name in {'.', '..'} or re.search(r'[<>:"/\\|?*\x00-\x1f]', archive_name) or archive_name.endswith(('.', ' ')):
        raise ValueError('Archive name must be a filename without path separators or reserved characters.')
    if settings.get('fill_zones'):
        pcbnew.ZONE_FILLER(board).Fill(board.Zones())
    root = Path(destination)
    if root.name != 'Fabrication files':
        root = root / 'Fabrication files'
    root.mkdir(parents=True, exist_ok=True)
    output_root = root
    # Build a fresh package in temporary storage so previous output is never re-packed.
    staging = tempfile.TemporaryDirectory(prefix='diyipcb-fabrication-')
    root = Path(staging.name)
    gerbers = root / 'gerber'
    gerbers.mkdir()
    if settings.get('backup_pcb'):
        pcbnew.SaveBoard(str(root / (source.stem + '-Export-snapshot.kicad_pcb')), board)
    warnings, issues, rows, positions = [], [], [], []
    sch = schematic_fields(source, warnings)
    origin = board.GetDesignSettings().GetAuxOrigin()
    seen = set()
    for fp in sorted(board.GetFootprints(), key=lambda f: natural(f.GetReference())):
        if fp.IsExcludedFromBOM() and fp.IsExcludedFromPosFiles():
            continue
        ref = fp.GetReference()
        if ref in seen:
            raise ValueError('Duplicate PCB reference: ' + ref)
        seen.add(ref)
        pcb_fields = dict(fp.GetFieldsText())
        supplied = sch.get(ref, {})
        # Ref-only matching is unsafe after an unsynchronised schematic edit.
        if supplied and (supplied.get('Value') != fp.GetValue() or
                supplied.get('Footprint', '').split(':')[-1] != str(fp.GetFPID().GetLibItemName())):
            warnings.append(ref + ': schematic/PCB mismatch; schematic properties ignored.')
            supplied = {}
        fields = dict(supplied, **{k: v for k, v in pcb_fields.items() if v})
        fields.update(Reference=ref, Quantity='1', Value=fp.GetValue(),
                      Footprint=str(fp.GetFPID().GetUniStringLibId()))
        row = canonical(fields)
        pcb_canonical, sch_canonical = canonical(pcb_fields), canonical(supplied)
        for col in ['Manufacturer', 'Part Number', 'Substitution', 'Datasheet', 'LCSC Part #']:
            if pcb_canonical[col]:
                row[col] = pcb_canonical[col]
                if sch_canonical[col] and sch_canonical[col] != row[col]:
                    warnings.append(ref + ': conflicting ' + col + '; PCB field used.')
        row['DNP'] = 'Yes' if fp.IsDNP() or row['DNP'] == 'Yes' or 'dnp' in supplied else 'No'
        row['Mount_Type'] = 'SMD' if fp.GetAttributes() & pcbnew.FP_SMD else 'THT'
        recognized = {key(a) for c in COLUMNS for a in ALIASES.get(c, [c])}
        row.update({k: v for k, v in fields.items() if key(k) not in recognized})
        if not fp.IsExcludedFromBOM():
            rows.append(row)
            if row['DNP'] == 'No':
                for name in ['Manufacturer', 'Part Number', 'Footprint']:
                    if not row[name]:
                        issues.append({'Reference': ref, 'Field': name, 'Issue': 'Missing procurement field'})
        if row['DNP'] == 'No' and not fp.IsExcludedFromBOM() and not fp.IsExcludedFromPosFiles():
            pos = fp.GetPosition()
            positions.append({'Reference': ref, 'Value': row['Value'], 'Footprint': row['Footprint'],
                'X (mm)': f'{pcbnew.ToMM(pos.x-origin.x):.6f}',
                'Y (mm)': f'{-pcbnew.ToMM(pos.y-origin.y):.6f}',
                'Rotation (deg)': f'{fp.GetOrientation().AsDegrees()%360:.6f}',
                'Side': 'Bottom' if fp.IsFlipped() else 'Top', 'Mount_Type': row['Mount_Type']})
    rows = group_rows(rows)
    columns = COLUMNS + sorted({k for r in rows for k in r if k not in COLUMNS})
    bom = root / (source.stem + '-BOM.csv')
    csv_write(bom, columns, [r for r in rows if r['DNP'] == 'No'] if settings.get('exclude_dnp') else rows)
    if settings.get('exclude_dnp'):
        csv_write(root / (source.stem + '-BOM-All.csv'), columns, rows)
    csv_write(root / (source.stem + '-BOM-Assembly.csv'), columns, [r for r in rows if r['DNP'] == 'No'])
    cpl = root / (source.stem + '-CPL.csv')
    csv_write(cpl, ['Reference', 'Value', 'Footprint', 'X (mm)', 'Y (mm)', 'Rotation (deg)', 'Side', 'Mount_Type'], positions)
    csv_write(root / 'procurement-issues.csv', ['Reference', 'Field', 'Issue'], issues)
    plan = [(pcbnew.F_Cu, '', 'GTL'), (pcbnew.B_Cu, '', 'GBL'),
            (pcbnew.F_SilkS, '', 'GTO'), (pcbnew.B_SilkS, '', 'GBO'),
            (pcbnew.F_Mask, '', 'GTS'), (pcbnew.B_Mask, '', 'GBS'),
            (pcbnew.F_Paste, '-F_Paste', 'GPS'), (pcbnew.B_Paste, '-B_Paste', 'GBS'),
            (pcbnew.Edge_Cuts, '', 'GML')]
    inner = [l for l in board.GetEnabledLayers().CuStack() if l not in (pcbnew.F_Cu, pcbnew.B_Cu)]
    plan += [(layer, '', 'G' + str(i)) for i, layer in enumerate(inner, 1)]
    controller = pcbnew.PLOT_CONTROLLER(board)
    options = controller.GetPlotOptions()
    options.SetOutputDirectory(str(gerbers))
    options.SetPlotFrameRef(False)
    options.SetAutoScale(False)
    options.SetScale(1)
    options.SetMirror(False)
    options.SetUseAuxOrigin(True)
    options.SetUseGerberProtelExtensions(False)
    options.SetUseGerberAttributes(True)
    options.SetUseGerberX2format(True)
    options.SetIncludeGerberNetlistInfo(True)
    options.SetSubtractMaskFromSilk(True)
    options.SetDrillMarksType(0)
    layers = {}
    for layer, suffix, extension in plan:
        if not board.IsLayerEnabled(layer):
            continue
        controller.SetLayer(layer)
        if not controller.OpenPlotfile(board.GetLayerName(layer), pcbnew.PLOT_FORMAT_GERBER, board.GetLayerName(layer)):
            raise RuntimeError('Cannot open plot output: ' + board.GetLayerName(layer))
        produced = Path(controller.GetPlotFileName())
        try:
            if not controller.PlotLayer():
                raise RuntimeError('Gerber plot failed: ' + board.GetLayerName(layer))
        finally:
            controller.ClosePlot()
        target = gerbers / (source.stem + suffix + '.' + extension)
        produced.rename(target)
        layers[target.name] = board.GetLayerName(layer)
    writer = pcbnew.EXCELLON_WRITER(board)
    writer.SetOptions(False, False, origin, False)
    writer.SetFormat(True)
    writer.CreateDrillandMapFilesSet(str(gerbers), True, False)
    for drill in gerbers.glob('*.drl'):
        drill.rename(drill.with_suffix('.TXT'))
    if not list(gerbers.glob('*.TXT')) and any(p.GetDrillSize().x for f in board.GetFootprints() for p in f.Pads()):
        raise RuntimeError('Expected drill files were not generated.')
    manifest = {'format_version': 1, 'board': source.name, 'kicad': pcbnew.Version(),
        'board_geometry': board_geometry(board),
        'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'layers': layers, 'export_options': settings, 'origin_mm': [pcbnew.ToMM(origin.x), pcbnew.ToMM(origin.y)],
        'coordinates': 'Aux origin, X right, Y up, KiCad native rotation CCW; bottom not mirrored.',
        'procurement_fields_complete': not issues, 'missing_fields': len(issues), 'warnings': warnings,
        'notes': ['MPNs are designer supplied, not stock/lifecycle validated.',
                  'GPS = F.Paste; B_Paste.GBS = B.Paste; unsuffixed GBS = B.Mask.',
                  'Bottom rotation is KiCad native; assembler must validate orientation.',
                  'No DRC or electrical review is implied by export.']}
    (root / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    archive = root / (archive_name + '-Gerber.zip')
    with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(gerbers.iterdir()):
            z.write(f, f.name)
    package = root / (archive_name + '-Production.zip')
    with zipfile.ZipFile(package, 'w', zipfile.ZIP_DEFLATED) as z:
        for f in sorted(root.rglob('*')):
            if f.is_file() and f != package:
                z.write(f, f.relative_to(root))
    for file in sorted(root.rglob('*')):
        if file.is_file():
            target = output_root / file.relative_to(root)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(file, target)
    result = {'root': str(output_root), 'gerber': str(output_root / archive.name),
              'bom': str(output_root / bom.name), 'centroid': str(output_root / cpl.name),
              'package': str(output_root / package.name), 'manifest': manifest}
    staging.cleanup()
    return result

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('source')
    parser.add_argument('output')
    parser.add_argument('--normalize-bom', action='store_true')
    args = parser.parse_args()
    if args.normalize_bom:
        print(json.dumps({'rows': len(normalize_csv(args.source, args.output))}))
    else:
        import pcbnew
        print(json.dumps(export_board(pcbnew.LoadBoard(args.source), args.output), ensure_ascii=False))
