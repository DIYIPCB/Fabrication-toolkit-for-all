import os
import traceback
from pathlib import Path
import pcbnew
import wx
from .core import export_board

class GenerationDialog(wx.Dialog):
    def __init__(self, title, board_path):
        super().__init__(None, title=title, style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER)
        self.SetMinSize((620, 430))
        panel = wx.BoxSizer(wx.VERTICAL)
        panel.Add(wx.StaticText(self, label='Options:'), 0, wx.ALL, 12)
        panel.Add(wx.StaticText(self, label='Archive name (optional; defaults to the PCB name)'), 0, wx.LEFT | wx.RIGHT, 12)
        self.archive = wx.TextCtrl(self)
        panel.Add(self.archive, 0, wx.EXPAND | wx.ALL, 12)
        panel.Add(wx.StaticText(self, label='Output folder'), 0, wx.LEFT | wx.RIGHT, 12)
        self.destination = wx.DirPickerCtrl(self, path=str(Path(board_path).parent / 'Fabrication files'),
                                           message='Select production output folder', style=wx.DIRP_USE_TEXTCTRL)
        panel.Add(self.destination, 0, wx.EXPAND | wx.ALL, 12)
        self.fill = wx.CheckBox(self, label='Fill all zones before generation')
        self.fill.SetValue(True)
        self.dnp = wx.CheckBox(self, label='Exclude DNP components from the production BOM')
        self.dnp.SetValue(True)
        self.browser = wx.CheckBox(self, label='Open browser and import files to DIYIPCB after generation')
        self.browser.SetValue(True)
        self.backup = wx.CheckBox(self, label='Include a PCB snapshot in the production package')
        for control in [self.fill, self.dnp, self.browser, self.backup]:
            panel.Add(control, 0, wx.LEFT | wx.RIGHT | wx.BOTTOM, 12)
        note = wx.StaticText(self, label='Gerber, BOM and placement files will be imported into the PCB order page.\nKeep KiCad open during import. Review your options before submitting the order.')
        note.Wrap(580)
        panel.Add(note, 0, wx.EXPAND | wx.ALL, 12)
        buttons = wx.BoxSizer(wx.HORIZONTAL)
        buttons.Add(wx.Button(self, wx.ID_CANCEL, 'Cancel'), 0, wx.RIGHT, 8)
        generate = wx.Button(self, wx.ID_OK, 'Generate')
        generate.SetDefault()
        buttons.Add(generate, 1)
        panel.Add(buttons, 0, wx.EXPAND | wx.ALL, 12)
        self.SetSizerAndFit(panel)
        self.Centre()

    def selections(self):
        return self.destination.GetPath(), {
            'archive_name': self.archive.GetValue().strip(), 'fill_zones': self.fill.GetValue(),
            'exclude_dnp': self.dnp.GetValue(), 'backup_pcb': self.backup.GetValue(),
            'open_browser': self.browser.GetValue()}

class FabricationAction(pcbnew.ActionPlugin):
    def defaults(self):
        self.name = 'Fabrication Tookit for All'
        self.category = 'Manufacturing'
        self.description = 'Export manufacturing files (gerber files, BOM files & PNP files) for all PCB manufacturers. Supported by DIYIPCB.'
        self.show_toolbar_button = True
        self.icon_file_name = str(Path(__file__).with_name('icon.png'))

    def Run(self):
        board = pcbnew.GetBoard()
        if not board or not board.GetFileName():
            wx.MessageBox('Please save the PCB first.', self.name, wx.OK | wx.ICON_WARNING)
            return
        dialog = GenerationDialog(self.name, board.GetFileName())
        if dialog.ShowModal() != wx.ID_OK:
            dialog.Destroy()
            return
        target, settings = dialog.selections()
        dialog.Destroy()
        if not target:
            wx.MessageBox('Please select an output folder.', self.name, wx.OK | wx.ICON_WARNING)
            return
        try:
            with wx.BusyCursor():
                # Use the saved board so Gerber and schematic inputs are reproducible.
                # Unsaved editor changes must not silently disappear from the production package.
                if board.IsModified():
                    raise ValueError('Save your PCB changes before exporting production files.')
                result = export_board(pcbnew.LoadBoard(board.GetFileName()), target, settings)
            missing = result['manifest']['missing_fields']
            note = ('\nProcurement fields missing: %s. See procurement-issues.csv.' % missing) if missing else ''
            if settings['open_browser']:
                from .handoff import start_handoff
                try:
                    start_handoff(result)
                    note += '\nDIYIPCB order page opened. Keep KiCad open during file import.'
                except Exception as exc:
                    note += '\nFiles were exported, but browser import could not start: ' + str(exc)
                    note += '\nUpload the exported Gerber ZIP, BOM and CPL manually.'
            wx.MessageBox('Production files exported:\n' + result['root'] + note,
                          self.name, wx.OK | wx.ICON_INFORMATION)
        except Exception:
            wx.MessageBox(traceback.format_exc(), self.name, wx.OK | wx.ICON_ERROR)

class DIYIPCBAction(FabricationAction):
    def defaults(self):
        super().defaults()
        self.name = 'DIYIPCB Plug-in for KiCad'
        self.description = 'Export production files and import them into the DIYIPCB order page'
        self.send_to_diyipcb = True
